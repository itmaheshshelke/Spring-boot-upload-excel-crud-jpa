package ms.sp2.test.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import ms.sp2.test.model.Excel;

/**
 * Created by Mahesh Shelke On 29-01-2019.
 */

public class ExcelReader {

	public static List<Excel> excelData(String fileUploadPath) {
		// Creating a Workbook from an Excel file (.xls or .xlsx)
		Workbook workbook = null;
		List<Excel> excelList = new ArrayList<>();
		try {
			workbook = WorkbookFactory.create(new File(fileUploadPath));
			// Getting the Sheet at index zero
			Sheet sheet = workbook.getSheetAt(0);

			// Create a DataFormatter to format and get each cell's value as String
			DataFormatter dataFormatter = new DataFormatter();

			for (Row row : sheet) {
				for (Cell cell : row) {
					String cellValue = dataFormatter.formatCellValue(cell);
					System.out.print(cellValue + "\t");
				}
				System.out.println();
				if (row.getRowNum() != 0) {
					Excel excelObject = new Excel();
					excelObject.setFirstName(row.getCell(0).toString());
					excelObject.setLastName(row.getCell(1).toString());
					excelObject.setEmailId(row.getCell(2).toString());
					excelObject.setContactNo(row.getCell(3).toString());
					excelObject.setGender(row.getCell(4).toString());
					excelObject.setCountry(row.getCell(5).toString());
					excelObject.setPassword(row.getCell(6).toString());
					excelObject.setCreatedBy(1);
					excelObject.setCreatedOn(new Date());
					excelObject.setDelFlag('N');
					excelList.add(excelObject);
				}
			}
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return excelList;

	}

}
